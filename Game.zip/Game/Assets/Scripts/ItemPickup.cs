using UnityEngine;
using System.Collections.Generic;

public class ItemPickup : MonoBehaviour
{
    public string itemName;
    private bool canPickup = false;
    private InventoryManager playerInventory;
    private PlayerSpriteController playerSprites;
    private UniqueItemPickup uniqueItemComponent;

    private void Awake()
    {
        uniqueItemComponent = GetComponent<UniqueItemPickup>();
        if (uniqueItemComponent == null)
        {
            Debug.LogError($"Missing UniqueItemPickup component on {gameObject.name}");
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            canPickup = true;
            playerInventory = other.GetComponent<InventoryManager>();
            playerSprites = other.GetComponent<PlayerSpriteController>();
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            canPickup = false;
            playerInventory = null;
            playerSprites = null;
        }
    }

    private void Update()
    {
        if (canPickup && Input.GetKeyDown(KeyCode.F) && 
            playerSprites && !playerSprites.IsPlayingPickupAnimation())
        {
            ItemData itemData = Resources.Load<ItemData>($"Items/{itemName}");
            if (itemData != null && playerInventory != null && playerInventory.AddItem(itemData.CreateItem()))
            {
                ItemCollectionManager.Instance.MarkItemAsCollected(uniqueItemComponent.uniqueId);
                playerSprites.PlayPickupAnimation();
                StartCoroutine(DestroyAfterAnimation());
            }
        }
    }

    private System.Collections.IEnumerator DestroyAfterAnimation()
    {
        yield return new WaitForSeconds(0.5f);
        Destroy(gameObject);
    }
}