using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
[RequireComponent(typeof(EnemyAnimator))]
public class EnemyController : MonoBehaviour
{
    [Header("Behavior Settings")]
    [SerializeField] private float detectionRadius = 5f;
    [SerializeField] private float zoneRadius = 8f;
    [SerializeField] private float passiveSpeed = 2f;
    [SerializeField] private float activeSpeed = 5f;
    [SerializeField] private float idleTime = 2f;
    [SerializeField] private float walkTime = 3f;

    [Header("References")]
    [SerializeField] private Transform player;
    private Rigidbody2D rb;
    private EnemyAnimator enemyAnimator;
    private Vector2 spawnPoint;
    private Vector2 currentTarget;
    
    private enum EnemyState { Idle, Wandering, Chasing }
    private EnemyState currentState;
    private float stateTimer;
    private Vector2 wanderDirection;
    private bool isFacingRight = true;

    private void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        enemyAnimator = GetComponent<EnemyAnimator>();
        spawnPoint = transform.position;
        currentState = EnemyState.Idle;
        stateTimer = idleTime;
    }

    private void Update()
    {
        if (player != null)
        {
            float distanceToPlayer = Vector2.Distance(transform.position, player.position);
            
            if (distanceToPlayer <= detectionRadius)
            {
                currentState = EnemyState.Chasing;
            }
            else if (currentState == EnemyState.Chasing)
            {
                currentState = EnemyState.Idle;
                stateTimer = idleTime;
            }
        }

        stateTimer -= Time.deltaTime;
        if (stateTimer <= 0 && currentState != EnemyState.Chasing)
        {
            ChangeState();
        }

        UpdateBehavior();
    }

    private void UpdateBehavior()
    {
        Vector2 movement = Vector2.zero;

        switch (currentState)
        {
            case EnemyState.Idle:
                enemyAnimator.SetIdle();
                break;

            case EnemyState.Wandering:
                movement = wanderDirection * passiveSpeed;
                enemyAnimator.UpdateWalkingAnimation();
                break;

            case EnemyState.Chasing:
                if (player != null)
                {
                    Vector2 directionToPlayer = ((Vector2)player.position - (Vector2)transform.position).normalized;
                    movement = directionToPlayer * activeSpeed;
                    enemyAnimator.UpdateRunningAnimation();
                }
                break;
        }

        rb.linearVelocity = movement;

        if (movement.x > 0 && !isFacingRight)
            Flip();
        else if (movement.x < 0 && isFacingRight)
            Flip();

        if (Vector2.Distance(spawnPoint, rb.position) > zoneRadius)
        {
            Vector2 directionToSpawn = (spawnPoint - rb.position).normalized;
            rb.position = rb.position + (Vector2)(directionToSpawn * passiveSpeed * Time.deltaTime);
        }
    }

    private void ChangeState()
    {
        if (currentState == EnemyState.Idle)
        {
            currentState = EnemyState.Wandering;
            stateTimer = walkTime;
            wanderDirection = Random.insideUnitCircle.normalized;
        }
        else
        {
            currentState = EnemyState.Idle;
            stateTimer = idleTime;
        }
    }

    private void Flip()
    {
        isFacingRight = !isFacingRight;
        Vector3 scale = transform.localScale;
        scale.x *= -1;
        transform.localScale = scale;
    }
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
        HealthSystem playerHealth = collision.gameObject.GetComponent<HealthSystem>();
            if (playerHealth != null)
            {
            playerHealth.TakeDamageWithKnockback(1, transform.position);
            }
        }
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, detectionRadius);
        
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(Application.isPlaying ? spawnPoint : transform.position, zoneRadius);
    }
}