using UnityEngine;
using UnityEngine.UI;

public class ResearchTable : MonoBehaviour
{
    [Header("UI References")]
    public GameObject researchUI;
    public RawImage flowerDisplay;
    public Image magnifyingGlassCursor;
    public float requiredUncoverPercentage = 70f;
    
    [Header("Rendering")]
    public Material unveilMaterial;

    [Header("Brush Settings")]
    public float brushSize = 0.1f;
    public float brushAlpha = 0.02f;
    public float brushScale = 0.1f;
    
    private RenderTexture maskTexture;
    private bool isResearching;
    private InventoryManager playerInventory;
    private Item currentFlower;
    private float uncoveredPercentage;
    private bool canInteract = false;
    private int totalPixelsRevealed = 0;
    private static readonly int TotalPixels = 512 * 512;
    private RenderTexture readbackRT;
    private JournalManager journalManager;
    
    void Start()
    {
        journalManager = FindObjectOfType<JournalManager>();
        playerInventory = FindObjectOfType<InventoryManager>();
        researchUI.SetActive(false);
        magnifyingGlassCursor.gameObject.SetActive(false);
        InitializeMaskTexture();
        SetupUnveilMaterial();
    }
    
   void InitializeMaskTexture()
    {
        maskTexture = new RenderTexture(512, 512, 0, RenderTextureFormat.ARGB32);
        maskTexture.Create();
        readbackRT = new RenderTexture(512, 512, 0, RenderTextureFormat.ARGB32)
        {
            enableRandomWrite = true
        };
        readbackRT.Create();
    }
    
    void SetupUnveilMaterial()
    {
        unveilMaterial.SetTexture("_MaskTex", maskTexture);
    }
    
    void PrepareNewResearch()
    {
        RenderTexture.active = maskTexture;
        GL.Clear(true, true, Color.black);
        RenderTexture.active = null;
        
        totalPixelsRevealed = 0;
        uncoveredPercentage = 0f;
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            canInteract = true;
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            canInteract = false;
            if (isResearching)
            {
                CloseResearch();
            }
        }
    }
    
    void Update()
    {
        if (canInteract && Input.GetKeyDown(KeyCode.F) && !isResearching)
        {
            StartResearch();
        }
        
        if (isResearching)
        {
            if (Input.GetKeyDown(KeyCode.Escape))
            {
                CloseResearch();
                return;
            }
            
            Vector2 mousePos = Input.mousePosition;
            magnifyingGlassCursor.transform.position = mousePos;
            
            if (Input.GetMouseButton(0))
            {
                Vector2 uv = ScreenToUV(mousePos);
                if (IsUVInBounds(uv))
                {
                    PaintMaskAtPosition(uv);
                    CalculateUncoveredPercentage();
                    
                    if (uncoveredPercentage >= requiredUncoverPercentage)
                    {
                        CompleteResearch();
                    }
                }
            }
        }
    }

    bool IsUVInBounds(Vector2 uv)
    {
        return uv.x >= 0 && uv.x <= 1 && uv.y >= 0 && uv.y <= 1;
    }
    
    Vector2 ScreenToUV(Vector2 screenPos)
    {
        RectTransform rt = flowerDisplay.rectTransform;
        Vector2 localPoint;
        RectTransformUtility.ScreenPointToLocalPointInRectangle(rt, screenPos, null, out localPoint);
        Vector2 normalized = new Vector2(
            (localPoint.x + rt.rect.width/2) / rt.rect.width,
            1 - ((localPoint.y + rt.rect.height/2) / rt.rect.height)  // Flip Y coordinate
        );
        return normalized;
    }
    
    void PaintMaskAtPosition(Vector2 uv)
    {
        RenderTexture.active = maskTexture;
        GL.PushMatrix();
        GL.LoadPixelMatrix(0, 1, 1, 0);
        float size = brushSize * brushScale;
        Color revealColor = new Color(1, 1, 1, brushAlpha);

        Graphics.DrawTexture(
            new Rect(uv.x - size/2, uv.y - size/2, size, size),
            Texture2D.whiteTexture,
            new Rect(0, 0, 1, 1),
            0, 0, 0, 0,
            revealColor
        );
        GL.PopMatrix();
        RenderTexture.active = null;
    }
    
    void CalculateUncoveredPercentage()
    {
        Graphics.Blit(maskTexture, readbackRT);

        Texture2D temp = new Texture2D(512, 512, TextureFormat.RGBA32, false);
        RenderTexture.active = readbackRT;
        temp.ReadPixels(new Rect(0, 0, 512, 512), 0, 0);
        temp.Apply();
        RenderTexture.active = null;
        Color[] pixels = temp.GetPixels();
        float totalWhite = 0;
        for (int i = 0; i < pixels.Length; i++)
        {
            totalWhite += pixels[i].r;
        }
        uncoveredPercentage = (totalWhite / pixels.Length) * 100f;
        Debug.Log($"Uncovered: {uncoveredPercentage:F1}%");
        Destroy(temp);
    }

    public void StartResearch()
    {
        currentFlower = GetFirstFlowerFromInventory();
        if (currentFlower == null)
        {
            Debug.Log("No flower found in inventory!");
            return;
        }
        
        isResearching = true;
        researchUI.SetActive(true);
        flowerDisplay.material = unveilMaterial;
        flowerDisplay.texture = currentFlower.highQualitySprite.texture;
        
        PrepareNewResearch();
        
        Cursor.visible = false;
        magnifyingGlassCursor.gameObject.SetActive(true);
    }
    
    void CloseResearch()
    {
        isResearching = false;
        researchUI.SetActive(false);
        magnifyingGlassCursor.gameObject.SetActive(false);
        Cursor.visible = true;
        
        if (currentFlower != null && uncoveredPercentage < requiredUncoverPercentage)
        {
            playerInventory.AddItem(currentFlower);
        }
        currentFlower = null;
    }
    
    void CompleteResearch()
    {
        Debug.Log($"Research completed for flower: {currentFlower.itemName}");
        isResearching = false;
        Graphics.Blit(Texture2D.whiteTexture, maskTexture);
        if (journalManager != null && currentFlower != null)
        {
            journalManager.UnlockEntry(currentFlower.itemName);
        }
        Cursor.visible = true;
        magnifyingGlassCursor.gameObject.SetActive(false);
        researchUI.SetActive(false);
    }

    Item GetFirstFlowerFromInventory()
    {
        foreach (InventorySlot slot in playerInventory.slots)
        {
            Item item = slot.GetItem();
            if (item != null && item.type == ItemType.Flower)
            {
                slot.ClearSlot();
                return item;
            }
        }
        return null;
    }
}