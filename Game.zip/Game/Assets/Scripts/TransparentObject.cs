using UnityEngine;

public class TransparentObject : MonoBehaviour 
{
    private SpriteRenderer spriteRenderer;
    private TreeVegetationObject treeComponent;
    [Range(0f, 1f)] public float transparentAlpha = 0.3f;
    [Range(0.1f, 10f)] public float fadeSpeed = 5f;
    
    private bool isCurrentlyTransparent = false;
    private Transform playerTransform;
    private Bounds objectBounds;

    private void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        treeComponent = GetComponent<TreeVegetationObject>();
        playerTransform = GameObject.FindGameObjectWithTag("Player").transform;

        if (spriteRenderer != null)
        {
            objectBounds = spriteRenderer.bounds;
        }
        else if (treeComponent != null)
        {
            objectBounds = GetComponent<Collider2D>().bounds;
        }
    }

    private void Update()
    {
        if (playerTransform == null) return;

        bool shouldBeTransparent = ShouldBeTransparent();
        float targetAlpha = shouldBeTransparent ? transparentAlpha : 1f;
        
        if (treeComponent != null)
        {
            treeComponent.SetTransparency(targetAlpha, fadeSpeed);
        }

        else if (spriteRenderer != null)
        {
            Color color = spriteRenderer.color;
            color.a = Mathf.MoveTowards(color.a, targetAlpha, fadeSpeed * Time.deltaTime);
            spriteRenderer.color = color;
        }
    }

    private bool ShouldBeTransparent()
    {
        if (playerTransform.position.y <= objectBounds.center.y) return false;

        Bounds playerBounds = playerTransform.GetComponent<Collider2D>().bounds;
        Bounds upperHalfBounds = new Bounds(
            new Vector3(objectBounds.center.x, 
                       objectBounds.center.y + objectBounds.extents.y/2, 
                       objectBounds.center.z),
            new Vector3(objectBounds.size.x, 
                       objectBounds.size.y/2, 
                       objectBounds.size.z)
        );
        
        return playerBounds.Intersects(upperHalfBounds);
    }
}