using UnityEngine;
using UnityEngine.UI;

public class StaminaSystem : MonoBehaviour
{
    [SerializeField] private float maxStamina = 80f;
    [SerializeField] private float staminaDrainPerSecond = 20f;
    [SerializeField] private float staminaRegenPerSecond = 5f;
    [SerializeField] private float regenCooldownDuration = 3f;
    
    [Header("UI Elements")]
    [SerializeField] private Image staminaBarImage;
    [SerializeField] private Sprite[] staminaBarSprites;
    
    private float currentStamina;
    private float regenCooldownTimer;
    private Player playerController;
    private bool canRun = true;
    private int currentSpriteIndex = -1;

    public bool CanRun => canRun && currentStamina > 0;

    private void Start()
    {
        playerController = GetComponent<Player>();
        currentStamina = maxStamina;
        
        if (staminaBarImage && staminaBarSprites?.Length > 0)
        {
            staminaBarImage.sprite = staminaBarSprites[0];
            currentSpriteIndex = 0;
        }
    }

    private void Update()
    {
        HandleStamina();
        UpdateUI();
    }

    private void HandleStamina()
    {
        bool isRunning = Input.GetKey(KeyCode.LeftShift) && canRun && 
                        (Input.GetAxisRaw("Horizontal") != 0 || Input.GetAxisRaw("Vertical") != 0);

        if (isRunning)
        {
            regenCooldownTimer = regenCooldownDuration;
            currentStamina = Mathf.Max(0, currentStamina - staminaDrainPerSecond * Time.deltaTime);
            
            if (currentStamina <= 0)
            {
                canRun = false;
                playerController?.ForceStopRunning();
            }
        }
        else if (currentStamina < maxStamina)
        {
            if (regenCooldownTimer > 0)
            {
                regenCooldownTimer -= Time.deltaTime;
                return;
            }

            currentStamina = Mathf.Min(maxStamina, currentStamina + staminaRegenPerSecond * Time.deltaTime);
            if (!canRun && currentStamina >= maxStamina * 0.25f) canRun = true;
        }
    }

    private void UpdateUI()
    {
        if (!staminaBarImage || staminaBarSprites == null || staminaBarSprites.Length <= 1) return;

        int targetIndex = Mathf.Clamp(
            Mathf.FloorToInt((maxStamina - currentStamina) / (maxStamina / (staminaBarSprites.Length - 1))),
            0, staminaBarSprites.Length - 1
        );
        
        if (targetIndex != currentSpriteIndex)
        {
            currentSpriteIndex = targetIndex;
            staminaBarImage.sprite = staminaBarSprites[targetIndex];
        }
    }
}