using UnityEngine;
using UnityEngine.UI;

public class InventoryWheel : MonoBehaviour
{
    [System.Serializable]
    public class Equipment
    {
        public string name;
        public Sprite icon;
    }

    [Header("UI States")]
    public Image wheelImage;
    public Sprite normalState;
    public Sprite leftArrowHighlight;
    public Sprite rightArrowHighlight;
    public float highlightDuration = 0.2f;

    [Header("Item Display")]
    public Image previousItemDisplay;
    public Image currentItemDisplay;
    public Image nextItemDisplay;

    [Header("Equipment")]
    public Equipment[] equipmentList;

    private int currentIndex = 0;
    private float stateTimer = 0f;
    private bool isTransitioning = false;

    void Start()
    {
        wheelImage.sprite = normalState;
        UpdateItemDisplays();
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Q))
        {
            RotateLeft();
        }
        else if (Input.GetKeyDown(KeyCode.E))
        {
            RotateRight();
        }

        if (isTransitioning && stateTimer > 0)
        {
            stateTimer -= Time.deltaTime;
            if (stateTimer <= 0)
            {
                wheelImage.sprite = normalState;
                isTransitioning = false;
            }
        }
    }

    void RotateLeft()
    {
        currentIndex = (currentIndex - 1 + equipmentList.Length) % equipmentList.Length;
        ShowLeftHighlight();
        UpdateItemDisplays();
        NotifySelectionChanged();
    }

    void RotateRight()
    {
        currentIndex = (currentIndex + 1) % equipmentList.Length;
        ShowRightHighlight();
        UpdateItemDisplays();
        NotifySelectionChanged();
    }

    void UpdateItemDisplays()
    {
        int prevIndex = (currentIndex - 1 + equipmentList.Length) % equipmentList.Length;
        int nextIndex = (currentIndex + 1) % equipmentList.Length;

        previousItemDisplay.sprite = equipmentList[prevIndex].icon;
        currentItemDisplay.sprite = equipmentList[currentIndex].icon;
        nextItemDisplay.sprite = equipmentList[nextIndex].icon;
    }

    void ShowLeftHighlight()
    {
        wheelImage.sprite = leftArrowHighlight;
        stateTimer = highlightDuration;
        isTransitioning = true;
    }

    void ShowRightHighlight()
    {
        wheelImage.sprite = rightArrowHighlight;
        stateTimer = highlightDuration;
        isTransitioning = true;
    }

    void NotifySelectionChanged()
    {
        Equipment selectedEquipment = equipmentList[currentIndex];
        Debug.Log($"Selected equipment: {selectedEquipment.name}");
    }

    public Equipment GetSelectedEquipment()
    {
        return equipmentList[currentIndex];
    }

    public int GetSelectedIndex()
    {
        return currentIndex;
    }
}