using UnityEngine;

public class PlayerSpawner : MonoBehaviour
{
    private void Start()
    {
    GameObject player = GameObject.FindGameObjectWithTag("Player");
    if (player != null)
        {
            float spawnX = PlayerPrefs.GetFloat("SpawnPositionX", transform.position.x);
            float spawnY = PlayerPrefs.GetFloat("SpawnPositionY", transform.position.y);
            player.transform.position = new Vector2(spawnX, spawnY);

            var inventoryManager = player.GetComponent<InventoryManager>();
            if (inventoryManager != null)
            {
                inventoryManager.Initialize();
            }
        
            GameManager.Instance.Initialize(player);
            GameManager.Instance.LoadPlayerData();
            PlayerPrefs.DeleteKey("SpawnPositionX");
            PlayerPrefs.DeleteKey("SpawnPositionY");
        }
    }
}