using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

public class DoorInteraction : MonoBehaviour
{
    [Header("Door Settings")]
    [SerializeField] private string targetSceneName;
    [SerializeField] private Vector2 spawnPosition;
    
    [Header("UI Prompt")]
    [SerializeField] private GameObject promptCanvas;
    [SerializeField] private TextMeshProUGUI promptText;
    
    private bool playerInRange = false;

    private void Start()
    {
        if (promptCanvas != null)
            promptCanvas.SetActive(false);
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            playerInRange = true;
            if (promptCanvas != null)
                promptCanvas.SetActive(true);
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            playerInRange = false;
            if (promptCanvas != null)
                promptCanvas.SetActive(false);
        }
    }

    private void Update()
    {
        if (playerInRange && Input.GetKeyDown(KeyCode.F))
        {
            TransitionToNewScene();
        }
    }

    private void TransitionToNewScene()
    {
        PlayerPrefs.SetFloat("SpawnPositionX", spawnPosition.x);
        PlayerPrefs.SetFloat("SpawnPositionY", spawnPosition.y);
        GameManager.Instance.SavePlayerData();
        SceneManager.LoadScene(targetSceneName);
    }
}