using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using UnityEngine.SceneManagement;

public class HealthSystem : MonoBehaviour
{
    [Header("Health Settings")]
    [SerializeField] private int maxHealth = 5;
    [SerializeField] private float invincibilityDuration = 1f;
    private int currentHealth;
    private bool isInvincible = false;

    [Header("UI Reference")]
    [SerializeField] private Image healthBarUI;
    [SerializeField] private Sprite[] healthStates;
    void Start()
    {
        currentHealth = maxHealth;
        UpdateHealthUI();
    }

    public void TakeDamage(int damage)
    {
        if (isInvincible) return;

        currentHealth = Mathf.Max(0, currentHealth - damage);
        UpdateHealthUI();
        
        if (currentHealth <= 0)
        {
            GameOver();
        }
        else
        {
            StartCoroutine(InvincibilityFrames());
        }
    }

    public void TakeDamageWithKnockback(int damage, Vector2 sourcePosition)
    {
    if (isInvincible) return;

    currentHealth = Mathf.Max(0, currentHealth - damage);
    UpdateHealthUI();
    
    Player playerMovement = GetComponent<Player>();
    if (playerMovement != null)
    {
        playerMovement.ApplyKnockback(sourcePosition);
    }
    
    if (currentHealth <= 0)
    {
        GameOver();
    }
    else
    {
        StartCoroutine(InvincibilityFrames());
    }
    }

    public void Heal(int amount)
    {
        currentHealth = Mathf.Min(maxHealth, currentHealth + amount);
        UpdateHealthUI();
    }

    private void UpdateHealthUI()
    {
        healthBarUI.sprite = healthStates[currentHealth];
    }

    private IEnumerator InvincibilityFrames()
    {
        isInvincible = true;
        
        SpriteRenderer playerSprite = GetComponent<SpriteRenderer>();
        if (playerSprite != null)
        {
            float elapsedTime = 0f;
            while (elapsedTime < invincibilityDuration)
            {
                playerSprite.enabled = !playerSprite.enabled;
                yield return new WaitForSeconds(0.1f);
                elapsedTime += 0.1f;
            }
            playerSprite.enabled = true;
        }
        else
        {
            yield return new WaitForSeconds(invincibilityDuration);
        }
        
        isInvincible = false;
    }

    private void GameOver()
    {
        Debug.Log("Game Over!");
    }

    public int GetCurrentHealth()
    {
        return currentHealth;
    }
}