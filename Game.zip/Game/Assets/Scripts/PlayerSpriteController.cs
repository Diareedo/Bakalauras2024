using UnityEngine;

[RequireComponent(typeof(SpriteRenderer))]
[RequireComponent(typeof(Player))]
public class PlayerSpriteController : MonoBehaviour
{
    [Header("Movement Animation Settings")]
    [SerializeField] private Sprite[] runningSprites;
    [SerializeField] private Sprite[] deceleratingSprites;
    [SerializeField] private Sprite idleSprite;
    [SerializeField] private float walkingFPS = 12f;
    [SerializeField] private float runningFPSMultiplier = 1.5f;

    [Header("Pickup Animation Settings")]
    [SerializeField] private Sprite[] pickupFrames;
    [SerializeField] private float pickupFPS = 10f;

    private SpriteRenderer spriteRenderer;
    private Player playerMovement;
    private Rigidbody2D rb;
    
    private float animationTimer;
    private int currentSpriteIndex;
    private bool isDecelerating;
    private Vector2 lastVelocity;
    private float currentFPS;

    private bool isPlayingPickupAnimation = false;
    private float pickupAnimationTimer = 0f;
    private int pickupFrameIndex = 0;

    private void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        playerMovement = GetComponent<Player>();
        rb = GetComponent<Rigidbody2D>();
        
        spriteRenderer.sprite = idleSprite;
        currentFPS = walkingFPS;

        playerMovement.OnSpeedChanged += HandleSpeedChanged;
    }

    private void OnDestroy()
    {
        if (playerMovement != null)
        {
            playerMovement.OnSpeedChanged -= HandleSpeedChanged;
        }
    }

    private void HandleSpeedChanged(bool isRunning)
    {
        currentFPS = isRunning ? walkingFPS * runningFPSMultiplier : walkingFPS;
    }

    private void Update()
    {
        if (isPlayingPickupAnimation)
        {
            UpdatePickupAnimation();
            return;
        }

        UpdateMovementAnimation();
    }

    private void UpdatePickupAnimation()
    {
        pickupAnimationTimer += Time.deltaTime;
        
        if (pickupAnimationTimer >= 1f / pickupFPS)
        {
            pickupAnimationTimer = 0f;
            pickupFrameIndex++;
            
            if (pickupFrameIndex >= pickupFrames.Length)
            {
                // Animation complete
                isPlayingPickupAnimation = false;
                spriteRenderer.sprite = idleSprite;
                return;
            }
            
            spriteRenderer.sprite = pickupFrames[pickupFrameIndex];
        }
    }

    private void UpdateMovementAnimation()
    {
        Vector2 currentVelocity = rb.linearVelocity;
        float speed = currentVelocity.magnitude;

        if (speed < lastVelocity.magnitude && speed > 0.1f && 
            Input.GetAxisRaw("Horizontal") == 0 && Input.GetAxisRaw("Vertical") == 0)
        {
            isDecelerating = true;
        }
        else if (isDecelerating && (Input.GetAxisRaw("Horizontal") != 0 || Input.GetAxisRaw("Vertical") != 0))
        {
            isDecelerating = false;
            currentSpriteIndex = 0;
        }
        else if (speed < 0.1f)
        {
            isDecelerating = false;
            spriteRenderer.sprite = idleSprite;
            currentSpriteIndex = 0;
            lastVelocity = currentVelocity;
            return;
        }

        animationTimer += Time.deltaTime;
        if (animationTimer >= 1f / currentFPS)
        {
            animationTimer = 0f;
            
            Sprite[] currentAnimation = isDecelerating ? deceleratingSprites : runningSprites;
            
            currentSpriteIndex = (currentSpriteIndex + 1) % currentAnimation.Length;
            spriteRenderer.sprite = currentAnimation[currentSpriteIndex];
            
            if (currentVelocity.x != 0)
            {
                spriteRenderer.flipX = currentVelocity.x < 0;
            }
        }
        
        lastVelocity = currentVelocity;
    }

    public float GetPickupAnimationDuration()
    {
        return (1f / pickupFPS) * pickupFrames.Length;
    }

    public void PlayPickupAnimation()
    {
        if (pickupFrames == null || pickupFrames.Length == 0)
        {
            Debug.LogError("No pickup frames assigned!");
            return;
        }

        isPlayingPickupAnimation = true;
        pickupFrameIndex = 0;
        pickupAnimationTimer = 0f;
        spriteRenderer.sprite = pickupFrames[0];
    }

    public bool IsPlayingPickupAnimation()
    {
        return isPlayingPickupAnimation;
    }
}