using UnityEngine;

[RequireComponent(typeof(SpriteRenderer))]
public class TreeVegetationObject : MonoBehaviour
{
    [SerializeField] private float swayAmount = 0.5f;
    [SerializeField] private float maxSway = 1f;
    [SerializeField] private int segments = 6;

    private MeshFilter meshFilter;
    private MeshRenderer meshRenderer;
    private Vector3[] baseVerts;
    private Vector3[] currentVerts;
    private WindSystem windSystem;
    private MaterialPropertyBlock propertyBlock;
    private float currentAlpha = 1f;

    private void Start()
    {
        windSystem = WindSystem.GetInstance();
        if (windSystem != null)
            windSystem.RegisterTreeObject(this);
            
        InitializeMesh();
    }

    public void SetTransparency(float targetAlpha, float fadeSpeed)
    {
        propertyBlock ??= new MaterialPropertyBlock();
        
        currentAlpha = Mathf.MoveTowards(currentAlpha, targetAlpha, fadeSpeed * Time.deltaTime);
        
        propertyBlock.Clear();
        propertyBlock.SetColor("_Color", new Color(1, 1, 1, currentAlpha));
        meshRenderer?.SetPropertyBlock(propertyBlock);
    }

    private void InitializeMesh()
    {
        var sprite = GetComponent<SpriteRenderer>();
        var meshObj = new GameObject("MeshObj") { transform = { parent = transform, localPosition = Vector3.zero } };
        
        meshFilter = meshObj.AddComponent<MeshFilter>();
        meshRenderer = meshObj.AddComponent<MeshRenderer>();
        
        SetupMaterial(sprite);
        CreateMeshGeometry(sprite);
        
        sprite.enabled = false;
    }

    private void SetupMaterial(SpriteRenderer sprite)
    {
        var material = new Material(Shader.Find("Sprites/Default"))
        {
            mainTexture = sprite.sprite.texture,
            color = sprite.color
        };

        material.SetFloat("_Mode", 2);
        material.SetInt("_SrcBlend", (int)UnityEngine.Rendering.BlendMode.SrcAlpha);
        material.SetInt("_DstBlend", (int)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha);
        material.SetInt("_ZWrite", 0);
        material.EnableKeyword("_ALPHABLEND_ON");
        material.renderQueue = 3000;

        meshRenderer.material = material;
        meshRenderer.sortingOrder = sprite.sortingOrder;
        meshRenderer.sortingLayerID = sprite.sortingLayerID;
        
        propertyBlock = new MaterialPropertyBlock();
    }

    private void CreateMeshGeometry(SpriteRenderer sprite)
    {
        var bounds = sprite.sprite.bounds;
        var texRect = sprite.sprite.textureRect;
        var tex = sprite.sprite.texture;
        
        baseVerts = new Vector3[4 * segments];
        currentVerts = new Vector3[4 * segments];
        var mesh = new Mesh();
        
        var uvs = CreateUVs(texRect, tex);
        var triangles = CreateTriangles();
        CreateVertices(bounds);

        mesh.vertices = baseVerts;
        mesh.uv = uvs;
        mesh.triangles = triangles;
        mesh.RecalculateNormals();
        meshFilter.mesh = mesh;
    }

    private Vector2[] CreateUVs(Rect texRect, Texture2D tex)
    {
        var uvs = new Vector2[4 * segments];
        float uvLeft = texRect.x / tex.width;
        float uvRight = (texRect.x + texRect.width) / tex.width;
        float uvBottom = texRect.y / tex.height;
        float uvTop = (texRect.y + texRect.height) / tex.height;

        for (int i = 0; i < segments; i++)
        {
            float t = i / (float)(segments - 1);
            int idx = i * 4;
            float uvY = Mathf.Lerp(uvBottom, uvTop, t);
            
            uvs[idx] = uvs[idx + 1] = new Vector2(uvLeft, uvY);
            uvs[idx + 2] = uvs[idx + 3] = new Vector2(uvRight, uvY);
        }

        return uvs;
    }

    private int[] CreateTriangles()
    {
        var tris = new int[6 * (segments - 1)];
        
        for (int i = 0; i < segments - 1; i++)
        {
            int baseIdx = i * 4;
            int triIdx = i * 6;
            
            tris[triIdx] = baseIdx;
            tris[triIdx + 1] = baseIdx + 4;
            tris[triIdx + 2] = baseIdx + 2;
            tris[triIdx + 3] = baseIdx + 2;
            tris[triIdx + 4] = baseIdx + 4;
            tris[triIdx + 5] = baseIdx + 6;
        }

        return tris;
    }

    private void CreateVertices(Bounds bounds)
    {
        float halfWidth = bounds.size.x / 2;
        
        for (int i = 0; i < segments; i++)
        {
            float t = i / (float)(segments - 1);
            float y = Mathf.Lerp(-bounds.size.y/2, bounds.size.y/2, t);
            int idx = i * 4;
            
            baseVerts[idx] = baseVerts[idx + 1] = new Vector3(-halfWidth, y);
            baseVerts[idx + 2] = baseVerts[idx + 3] = new Vector3(halfWidth, y);
        }
    }

    public void ApplyWindForce(float force)
    {
        force = Mathf.Clamp(force * swayAmount, -maxSway, maxSway);
        
        for (int i = 0; i < segments; i++)
        {
            float t = i / (float)(segments - 1);
            float sway = t * t * force;
            int idx = i * 4;
            
            Vector3 offset = new Vector3(sway, 0);
            for (int j = 0; j < 4; j++)
                currentVerts[idx + j] = baseVerts[idx + j] + offset;
        }
        
        if (meshFilter?.mesh != null)
        {
            meshFilter.mesh.vertices = currentVerts;
            meshFilter.mesh.RecalculateNormals();
        }
    }

    private void OnDestroy() => windSystem?.UnregisterTreeObject(this);
}