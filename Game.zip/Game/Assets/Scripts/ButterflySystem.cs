using UnityEngine;
using System.Collections.Generic;

[System.Serializable]
public class ButterflyType {
    public Sprite[] sprites;
    [Range(0.1f, 1f)]
    public float animationSpeed = 0.15f;
}

public class ButterflySystem : MonoBehaviour {
    [Header("Butterfly Configuration")]
    public ButterflyType[] butterflyTypes;
    public float spawnRadius = 20f;
    public float clusterRadius = 3f;
    [Range(1f, 60f)]
    public float spawnInterval = 15f;
    [Range(1, 10)]
    public int maxClusters = 6;
    
    [Header("Movement Configuration")]
    public float baseSpeed = 2f;
    public float zigzagFrequency = 2f;
    public float zigzagMagnitude = 0.5f;
    [Range(0f, 1f)]
    public float migrationChance = 0.1f;
    
    [Header("Despawn Configuration")]
    public float despawnRadius = 30f;
    
    private Transform playerTransform;
    private List<ButterflyCluster> activeClusters;
    private float nextSpawnTime;
    
    private void Start() {
        playerTransform = GameObject.FindGameObjectWithTag("Player").transform;
        activeClusters = new List<ButterflyCluster>();
        nextSpawnTime = Time.time + Random.Range(0f, spawnInterval);
    }
    
    private void Update() {
        if (Time.time >= nextSpawnTime && activeClusters.Count < maxClusters) {
            SpawnCluster();
            nextSpawnTime = Time.time + spawnInterval + Random.Range(-3f, 3f);
        }
        
        for (int i = activeClusters.Count - 1; i >= 0; i--) {
            float distanceToPlayer = Vector2.Distance(activeClusters[i].transform.position, playerTransform.position);
            if (distanceToPlayer > despawnRadius || !activeClusters[i].UpdateCluster()) {
                Destroy(activeClusters[i].gameObject);
                activeClusters.RemoveAt(i);
            }
        }
    }
    
    private void SpawnCluster() {
        Vector2 spawnOffset = Random.insideUnitCircle * spawnRadius;
        Vector3 spawnPos = playerTransform.position + new Vector3(spawnOffset.x, spawnOffset.y, 0);
        
        GameObject clusterObj = new GameObject("ButterflyCluster");
        clusterObj.transform.position = spawnPos;
        
        ButterflyCluster cluster = clusterObj.AddComponent<ButterflyCluster>();
        int butterflyCount = Random.value < 0.3f ? 1 : Random.Range(3, 7);
        
        cluster.Initialize(
            butterflyTypes,
            butterflyCount,
            clusterRadius,
            baseSpeed,
            zigzagFrequency,
            zigzagMagnitude,
            migrationChance
        );
        
        activeClusters.Add(cluster);
    }
}

public class ButterflyCluster : MonoBehaviour {
    private List<Butterfly> butterflies;
    private Vector2 centerPosition;
    private Vector2 targetPosition;
    private float clusterRadius;
    private float baseSpeed;
    private bool isMigrating;
    private float nextBehaviorChange;
    
    public void Initialize(
        ButterflyType[] types,
        int count,
        float radius,
        float speed,
        float zigzagFreq,
        float zigzagMag,
        float migrationChance
    ) {
        butterflies = new List<Butterfly>();
        clusterRadius = radius;
        baseSpeed = speed;
        centerPosition = transform.position;
        SetNewTarget();
        
        for (int i = 0; i < count; i++) {
            CreateButterfly(types, zigzagFreq, zigzagMag);
        }
        
        isMigrating = Random.value < migrationChance;
        nextBehaviorChange = Time.time + Random.Range(10f, 20f);
    }
    
    private void CreateButterfly(ButterflyType[] types, float zigzagFreq, float zigzagMag) {
        GameObject butterflyObj = new GameObject("Butterfly");
        butterflyObj.transform.SetParent(transform);
        
        Vector2 offset = Random.insideUnitCircle * clusterRadius;
        butterflyObj.transform.position = (Vector2)transform.position + offset;
        
        SpriteRenderer spriteRenderer = butterflyObj.AddComponent<SpriteRenderer>();
        spriteRenderer.transform.localScale = new Vector3(0.5f, 0.5f, 1f);
        spriteRenderer.sortingOrder = Random.Range(5, 15);
        
        Butterfly butterfly = butterflyObj.AddComponent<Butterfly>();
        ButterflyType selectedType = types[Random.Range(0, types.Length)];
        butterfly.Initialize(selectedType, zigzagFreq, zigzagMag);
        
        butterflies.Add(butterfly);
    }
    
    private void SetNewTarget() {
        if (isMigrating) {
            float angle = Random.Range(0f, 360f) * Mathf.Deg2Rad;
            Vector2 direction = new Vector2(Mathf.Cos(angle), Mathf.Sin(angle));
            targetPosition = centerPosition + direction * Random.Range(20f, 30f);
        } else {
            targetPosition = centerPosition + (Vector2)(Random.insideUnitCircle * 5f);
        }
    }
    
    public bool UpdateCluster() {
        if (Time.time >= nextBehaviorChange) {
            isMigrating = Random.value < 0.3f;
            nextBehaviorChange = Time.time + Random.Range(10f, 20f);
            SetNewTarget();
        }
        
        Vector2 moveDirection = (targetPosition - centerPosition).normalized;
        float speed = isMigrating ? baseSpeed * 1.5f : baseSpeed;
        centerPosition = Vector2.MoveTowards(centerPosition, targetPosition, speed * Time.deltaTime);
        transform.position = centerPosition;
        
        if (Vector2.Distance(centerPosition, targetPosition) < 0.1f) {
            SetNewTarget();
        }
        
        foreach (var butterfly in butterflies) {
            butterfly.UpdateButterfly(centerPosition);
        }
        
        return true;
    }
}

public class Butterfly : MonoBehaviour {
    private SpriteRenderer spriteRenderer;
    private ButterflyType butterflyType;
    private float animationTimer;
    private int currentFrame;
    private Vector2 localOffset;
    private float zigzagFrequency;
    private float zigzagMagnitude;
    private float individualOffset;
    
    public void Initialize(ButterflyType type, float zigzagFreq, float zigzagMag) {
        spriteRenderer = GetComponent<SpriteRenderer>();
        butterflyType = type;
        spriteRenderer.sprite = type.sprites[0];
        
        zigzagFrequency = zigzagFreq;
        zigzagMagnitude = zigzagMag;
        individualOffset = Random.Range(0f, Mathf.PI * 2f);
        localOffset = Random.insideUnitCircle;
    }
    
    public void UpdateButterfly(Vector2 clusterCenter) {
        animationTimer += Time.deltaTime;
        if (animationTimer >= butterflyType.animationSpeed) {
            animationTimer = 0f;
            currentFrame = (currentFrame + 1) % butterflyType.sprites.Length;
            spriteRenderer.sprite = butterflyType.sprites[currentFrame];
        }
        
        float time = Time.time + individualOffset;
        Vector2 zigzag = new Vector2(
            Mathf.Sin(time * zigzagFrequency) * zigzagMagnitude,
            Mathf.Cos(time * zigzagFrequency * 0.6f) * zigzagMagnitude
        );
        
        transform.position = (Vector2)clusterCenter + localOffset + zigzag;
        
        if (zigzag.x < 0) {
            transform.localScale = new Vector3(-0.5f, 0.5f, 1f);
        } else {
            transform.localScale = new Vector3(0.5f, 0.5f, 1f);
        }
    }
}