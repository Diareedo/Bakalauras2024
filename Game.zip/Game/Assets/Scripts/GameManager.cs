using UnityEngine;
using System.Collections.Generic;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }
    private HealthSystem healthSystem;
    private StaminaSystem staminaSystem;
    private InventoryManager inventoryManager;
    [System.Serializable]
    private class InventoryData
    {
        public List<string> items;
    }

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    public void Initialize(GameObject player)
    {
        healthSystem = player.GetComponent<HealthSystem>();
        staminaSystem = player.GetComponent<StaminaSystem>();
        inventoryManager = player.GetComponent<InventoryManager>();
    }

    public void SavePlayerData()
    {
        if (healthSystem != null)
        {
            PlayerPrefs.SetInt("PlayerHealth", healthSystem.GetCurrentHealth());
        }

        if (staminaSystem != null)
        {
            PlayerPrefs.SetFloat("PlayerStamina", staminaSystem.CanRun ? 80f : 0f);
        }

        if (inventoryManager != null)
        {
            SaveInventory();
            string savedData = PlayerPrefs.GetString("InventoryData");
            Debug.Log($"SAVING INVENTORY DATA: {savedData}");
            PlayerPrefs.Save();
        }

        PlayerPrefs.Save();
    }

    public void LoadPlayerData()
    {
        if (healthSystem != null)
        {
            int savedHealth = PlayerPrefs.GetInt("PlayerHealth", 5);
            int currentHealth = healthSystem.GetCurrentHealth();
            if (savedHealth > currentHealth)
            {
                healthSystem.Heal(savedHealth - currentHealth);
            }
            else if (savedHealth < currentHealth)
            {
                healthSystem.TakeDamage(currentHealth - savedHealth);
            }
        }

        if (inventoryManager != null)
        {
            LoadInventory();
        }
    }

    private void SaveInventory()
    {
        if (inventoryManager.slots == null) return;

        List<string> itemNames = new List<string>();
        foreach (InventorySlot slot in inventoryManager.slots)
        {
            if (!slot.isEmpty)
            {
                Item item = slot.GetItem();
                if (item != null)
                {
                    itemNames.Add(item.itemName);
                }
            }
        }

        InventoryData inventoryData = new InventoryData
        {
            items = itemNames
        };

        string inventoryJson = JsonUtility.ToJson(inventoryData);
        PlayerPrefs.SetString("InventoryData", inventoryJson);
    }

    private void LoadInventory()
    {
        if (inventoryManager.slots == null)
        {
            Debug.LogWarning("No inventory slots found!");
            return;
        }

        if (inventoryManager != null && inventoryManager.slots != null)
        {
            foreach (var slot in inventoryManager.slots)
            {
                if (slot != null) slot.ClearSlot();
            }
        }

        string inventoryJson = PlayerPrefs.GetString("InventoryData", "");

        if (string.IsNullOrEmpty(inventoryJson))
        {
            Debug.LogWarning("No saved inventory data found!");
            return;
        }

        Debug.Log($"Loading inventory data: {inventoryJson}");
        InventoryData data = JsonUtility.FromJson<InventoryData>(inventoryJson);

        if (data?.items == null)
        {
            Debug.LogWarning("Failed to deserialize inventory data!");
            return;
        }
        Debug.Log($"Found {data.items.Count} items to load");
        foreach (InventorySlot slot in inventoryManager.slots)
        {
            if (!slot.isEmpty)
            {
                slot.ClearSlot();
            }
        }

        foreach (string itemName in data.items)
        {
            Debug.Log($"Trying to load item: {itemName}");
            ItemData itemData = Resources.Load<ItemData>($"Items/{itemName}");
        
            if (itemData != null)
            {
                Debug.Log($"Successfully loaded item: {itemName}");
                Item item = itemData.CreateItem();
                inventoryManager.AddItem(item);
            }
            else
            {
                Debug.LogError($"Failed to load item: {itemName}");
            }
        }
    }
}