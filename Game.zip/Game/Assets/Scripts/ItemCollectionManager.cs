using UnityEngine;
using System.Collections.Generic;

public class ItemCollectionManager : MonoBehaviour
{
    private static ItemCollectionManager instance;
    private HashSet<string> collectedItems = new HashSet<string>();

    public static ItemCollectionManager Instance
    {
        get
        {
            if (instance == null)
            {
                var obj = new GameObject("ItemCollectionManager");
                instance = obj.AddComponent<ItemCollectionManager>();
                DontDestroyOnLoad(obj);
            }
            return instance;
        }
    }

    private void Awake()
    {
        if (instance != null && instance != this)
        {
            Destroy(gameObject);
            return;
        }
        instance = this;
        DontDestroyOnLoad(gameObject);
        LoadCollectedItems();
    }

    public void MarkItemAsCollected(string itemId)
    {
        collectedItems.Add(itemId);
        SaveCollectedItems();
    }

    public bool HasItemBeenCollected(string itemId)
    {
        return collectedItems.Contains(itemId);
    }

    private void SaveCollectedItems()
    {
        string itemsJson = JsonUtility.ToJson(new SerializableItemList(collectedItems));
        PlayerPrefs.SetString("CollectedItems", itemsJson);
        PlayerPrefs.Save();
    }

    private void LoadCollectedItems()
    {
        string itemsJson = PlayerPrefs.GetString("CollectedItems", "");
        if (!string.IsNullOrEmpty(itemsJson))
        {
            var itemList = JsonUtility.FromJson<SerializableItemList>(itemsJson);
            collectedItems = new HashSet<string>(itemList.items);
        }
    }

    [System.Serializable]
    private class SerializableItemList
    {
        public List<string> items;

        public SerializableItemList(HashSet<string> hashSet)
        {
            items = new List<string>(hashSet);
        }
    }
}