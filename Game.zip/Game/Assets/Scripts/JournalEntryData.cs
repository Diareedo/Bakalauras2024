using UnityEngine;

[CreateAssetMenu(fileName = "New Journal Entry", menuName = "Journal/Entry")]
public class JournalEntryData : ScriptableObject
{
    public string plantName;
    public Sprite pageSpread;
}