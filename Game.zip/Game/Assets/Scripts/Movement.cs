using UnityEngine;

[RequireComponent(typeof(Rigidbody2D), typeof(StaminaSystem))]
public class Player : MonoBehaviour
{
    [Header("Movement Settings")]
    [SerializeField] private float walkSpeed = 3.0f;
    [SerializeField] private float runSpeedMultiplier = 2.0f;
    [SerializeField] private float acceleration = 25.0f;
    [SerializeField] private float deceleration = 5.0f;

    [Header("Knockback Settings")]
    [SerializeField] private float knockbackForce = 10f;
    [SerializeField] private float knockbackDuration = 0.25f;

    public event System.Action<bool> OnSpeedChanged;
    public bool IsRunning => isRunning;

    private Rigidbody2D rb;
    private StaminaSystem staminaSystem;
    private Vector2 velocity;
    private bool isRunning;
    private bool isKnockedBack;
    private float knockbackTimer;

    private void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        staminaSystem = GetComponent<StaminaSystem>();
    }

    private void Update()
    {
        if (HandleKnockback()) return;
        HandleMovement();
    }

    private bool HandleKnockback()
    {
        if (!isKnockedBack) return false;
        
        knockbackTimer -= Time.deltaTime;
        if (knockbackTimer <= 0)
        {
            isKnockedBack = false;
            velocity = Vector2.zero;
        }
        return true;
    }

    private void HandleMovement()
    {
        Vector2 direction = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));
        bool isMoving = direction.sqrMagnitude > 0;
        bool wasRunning = isRunning;
        
        isRunning = isMoving && Input.GetKey(KeyCode.LeftShift) && staminaSystem.CanRun;
        
        if (wasRunning != isRunning)
        {
            OnSpeedChanged?.Invoke(isRunning);
        }

        float targetSpeed = isRunning ? walkSpeed * runSpeedMultiplier : walkSpeed;
        float currentAcceleration = isMoving ? acceleration : deceleration;
        Vector2 targetVelocity = isMoving ? direction.normalized * targetSpeed : Vector2.zero;
        
        velocity = Vector2.MoveTowards(velocity, targetVelocity, currentAcceleration * Time.deltaTime);
        rb.linearVelocity = velocity;
    }

    public void ApplyKnockback(Vector2 sourcePosition)
    {
        if (isKnockedBack) return;

        Vector2 knockbackDirection = ((Vector2)transform.position - sourcePosition).normalized;
        velocity = knockbackDirection * knockbackForce;
        isKnockedBack = true;
        knockbackTimer = knockbackDuration;
        
        ForceStopRunning();
    }

    public void ForceStopRunning()
    {
        if (isRunning)
        {
            isRunning = false;
            OnSpeedChanged?.Invoke(false);
        }
    }
}