using UnityEngine;
using UnityEngine.UI;

public class InventorySlot : MonoBehaviour
{
    private Image slotImage;
    public Item item;
    public bool isEmpty = true;

    void Awake()
    {
        slotImage = GetComponent<Image>();
        ClearSlot();
    }

    public void AddItem(Item newItem)
    {
        item = newItem;
        if (item != null && slotImage != null)
        {
            slotImage.sprite = item.icon;
            slotImage.enabled = true;
            isEmpty = false;
        }
    }

    public void ClearSlot()
    {
        item = null;
        slotImage.sprite = null;
        slotImage.enabled = false;
        isEmpty = true;
    }

    public Item GetItem()
    {
        return item;
    }
}