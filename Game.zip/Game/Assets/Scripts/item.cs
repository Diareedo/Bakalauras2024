using UnityEngine;

public enum ItemType
{
    Flower,
    Other
}

[CreateAssetMenu(fileName = "New Item", menuName = "Inventory/Item")]
public class ItemData : ScriptableObject
{
    public string itemName;
    public ItemType type;
    public Sprite icon;  // inventory sprite
    public Sprite highQualitySprite;  // sprite for research
    public string description;

    public Item CreateItem()
    {
        return new Item(this);
    }
}

[System.Serializable]
public class Item
{
    public string itemName;
    public ItemType type;
    public Sprite icon;
    public Sprite highQualitySprite;
    public string description;

    public Item(ItemData data)
    {
        itemName = data.itemName;
        type = data.type;
        icon = data.icon;
        highQualitySprite = data.highQualitySprite;
        description = data.description;
    }
}