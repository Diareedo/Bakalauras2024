using UnityEngine;
using System.Collections.Generic;

[System.Serializable]
public class UniqueItemPickup : MonoBehaviour
{
    public string uniqueId;
    
    private void Start()
    {
        if (ItemCollectionManager.Instance.HasItemBeenCollected(uniqueId))
        {
            Destroy(gameObject);
        }
    }
}