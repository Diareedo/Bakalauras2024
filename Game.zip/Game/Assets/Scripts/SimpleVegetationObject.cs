using UnityEngine;

public class SimpleVegetationObject : MonoBehaviour
{
    [SerializeField] private float swayAmount = 5f;
    [SerializeField] private float recoverySpeed = 5f;
    [SerializeField] private float maxSway = 10f;
    
    private Quaternion originalRotation, targetRotation;
    private WindSystem windSystem;
    private GameObject holder;
    private Vector3 startPos;

    private void Start()
    {
        if (holder == null) SetupHolder();
        
        originalRotation = targetRotation = transform.rotation;
        
        if (WindSystem.GetInstance() != null)
            windSystem = WindSystem.GetInstance();
            windSystem.RegisterSimpleObject(this);
    }

    private void SetupHolder()
    {
        startPos = transform.position;
        var sprite = GetComponent<SpriteRenderer>();
        
        holder = new GameObject("Holder");
        holder.transform.SetParent(transform);
        holder.transform.localPosition = new Vector3(0, sprite.bounds.size.y/2, 0);
        
        sprite.transform.SetParent(holder.transform);
        sprite.transform.localPosition = Vector3.zero;
        
        transform.position = startPos;
    }

    private void OnDestroy() => windSystem?.UnregisterSimpleObject(this);

    public void ApplyWindForce(float force)
    {
        float rotation = Mathf.Clamp(force * swayAmount, -maxSway, maxSway);
        targetRotation = Quaternion.Euler(0, 0, rotation);
    }

    private void Update()
    {
        transform.rotation = Quaternion.Lerp(
            transform.rotation, 
            targetRotation, 
            recoverySpeed * Time.deltaTime
        );
    }
}