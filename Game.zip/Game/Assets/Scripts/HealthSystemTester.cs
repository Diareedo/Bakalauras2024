using UnityEngine;

public class HealthSystemTester : MonoBehaviour
{
    private HealthSystem healthSystem;

    void Start()
    {
        healthSystem = GetComponent<HealthSystem>();
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Mouse2))
        {
            Debug.Log($"Current health = {healthSystem.GetCurrentHealth()}");
        }

        if (Input.GetKeyDown(KeyCode.Mouse0))
        {
            int oldHealth = healthSystem.GetCurrentHealth();
            healthSystem.TakeDamage(1);
            Debug.Log($"Current health = {oldHealth}, removing 1, new health = {healthSystem.GetCurrentHealth()}");
        }

        if (Input.GetKeyDown(KeyCode.Mouse1))
        {
            int oldHealth = healthSystem.GetCurrentHealth();
            healthSystem.Heal(1);
            Debug.Log($"Current health = {oldHealth}, adding 1, new health = {healthSystem.GetCurrentHealth()}");
        }
    }
}