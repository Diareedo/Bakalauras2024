using UnityEngine;
using System.Collections.Generic;

public class WindSystem : MonoBehaviour
{
    [Header("Wind Wave Settings")]
    [SerializeField] private float windSpeed = 5f;
    [SerializeField] private float windStrength = 0.5f;
    [SerializeField] private float windFrequency = 10f;
    [SerializeField] private float windWaveWidth = 3f;
    
    [Header("Random Wind Settings")]
    [SerializeField] private float minTimeBetweenGusts = 3f;
    [SerializeField] private float maxTimeBetweenGusts = 8f;
    
    [Header("World Settings")]
    [SerializeField] private float effectiveRange = 20f;
    [SerializeField] private Transform player;
    
    private float nextGustTime;
    private float currentWavePosition;
    private bool isWindActive = false;
    private Camera mainCamera;
    
    private static WindSystem instance;
    private List<SimpleVegetationObject> simpleObjects = new List<SimpleVegetationObject>();
    private List<TreeVegetationObject> treeObjects = new List<TreeVegetationObject>();

    private void Awake()
    {
        instance = this;
    }

    private void Start()
    {
        mainCamera = Camera.main;
        SetNextGustTime();

        if (player == null)
        {
            player = GameObject.FindGameObjectWithTag("Player")?.transform;
            if (player == null)
                Debug.LogWarning("WindSystem: No player reference set! Please assign player in inspector or tag your player as 'Player'");
        }
    }

    private void Update()
    {
        if (!isWindActive && Time.time >= nextGustTime)
        {
            StartWindGust();
        }

        if (isWindActive)
        {
            UpdateWindWave();
        }
    }

    private void UpdateWindWave()
    {
        currentWavePosition += windSpeed * Time.deltaTime;
        Vector3 centerPosition = player != null ? player.position : mainCamera.transform.position;
        float leftBoundary = centerPosition.x - effectiveRange;
        float rightBoundary = centerPosition.x + effectiveRange;

        foreach (var vegetation in simpleObjects)
        {
            if (vegetation == null) continue;

            if (vegetation.transform.position.x < leftBoundary || 
                vegetation.transform.position.x > rightBoundary) 
            {
                vegetation.ApplyWindForce(0);
                continue;
            }
            
            float distanceFromWave = Mathf.Abs(vegetation.transform.position.x - currentWavePosition);
            
            if (distanceFromWave < windWaveWidth)
            {
                float influence = 1 - (distanceFromWave / windWaveWidth);
                float windEffect = windStrength * influence * Mathf.Sin(Time.time * windFrequency);
                vegetation.ApplyWindForce(windEffect);
            }
            else
            {
                vegetation.ApplyWindForce(0);
            }
        }

        foreach (var tree in treeObjects)
        {
            if (tree == null) continue;

            if (tree.transform.position.x < leftBoundary || 
                tree.transform.position.x > rightBoundary)
            {
                tree.ApplyWindForce(0);
                continue;
            }
            
            float distanceFromWave = Mathf.Abs(tree.transform.position.x - currentWavePosition);
            
            if (distanceFromWave < windWaveWidth)
            {
                float influence = 1 - (distanceFromWave / windWaveWidth);
                float windEffect = windStrength * influence * Mathf.Sin(Time.time * windFrequency);
                tree.ApplyWindForce(windEffect);
            }
            else
            {
                tree.ApplyWindForce(0);
            }
        }

        if (currentWavePosition > centerPosition.x + effectiveRange)
        {
            isWindActive = false;
            SetNextGustTime();
        }
    }

    private void StartWindGust()
    {
        isWindActive = true;
        currentWavePosition = player != null 
            ? player.position.x - effectiveRange 
            : mainCamera.transform.position.x - effectiveRange;
    }

    private void SetNextGustTime()
    {
        nextGustTime = Time.time + Random.Range(minTimeBetweenGusts, maxTimeBetweenGusts);
    }


    public static WindSystem GetInstance()
    {
        return instance;
    }

    public void RegisterSimpleObject(SimpleVegetationObject vegetation)
    {
        if (!simpleObjects.Contains(vegetation))
        {
            simpleObjects.Add(vegetation);
        }
    }

    public void UnregisterSimpleObject(SimpleVegetationObject vegetation)
    {
        simpleObjects.Remove(vegetation);
    }

    public void RegisterTreeObject(TreeVegetationObject tree)
    {
        if (!treeObjects.Contains(tree))
        {
            treeObjects.Add(tree);
        }
    }

    public void UnregisterTreeObject(TreeVegetationObject tree)
    {
        treeObjects.Remove(tree);
    }
}