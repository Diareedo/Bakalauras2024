using UnityEngine;

public class InventoryManager : MonoBehaviour
{
    public GameObject inventoryUI;
    public InventorySlot[] slots;
    private bool isInitialized = false;

    void Start()
    {
        InitializeInventory();
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Tab))
        {
            inventoryUI.SetActive(!inventoryUI.activeSelf);
        }
    }

    public void Initialize()
    {
        InitializeInventory();
    }

    private void InitializeInventory()
    {
        if (isInitialized) return;

        bool wasActive = inventoryUI.activeSelf;
        inventoryUI.SetActive(true);
        slots = inventoryUI.GetComponentsInChildren<InventorySlot>(true);
        inventoryUI.SetActive(wasActive);
        
        isInitialized = true;
        Debug.Log($"Initialized inventory with {slots.Length} slots");
    }

    public bool AddItem(Item item)
    {
        if (!isInitialized) InitializeInventory();
        
        for (int i = 0; i < slots.Length; i++)
        {
            if (slots[i].isEmpty)
            {
                slots[i].AddItem(item);
                return true;
            }
        }
        return false;
    }
}