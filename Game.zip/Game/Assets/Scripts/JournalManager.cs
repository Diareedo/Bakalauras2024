using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using System.Collections;

public class JournalManager : MonoBehaviour
{
    public static JournalManager Instance { get; private set; }
    
    [Header("Prefab Reference")]
    [SerializeField] private GameObject journalPrefab;
    
    [Header("Audio")]
    [SerializeField] private AudioClip pageFlipSound;
    [SerializeField] private AudioClip unlockSound;
    
    [Header("Data")]
    [SerializeField] private JournalDatabase journalDatabase;
    
    [Header("Effects")]
    [SerializeField] private GameObject sparkleEffectPrefab;
    
    private GameObject journalInstance;
    private Image bookPages;
    private int currentPage = 0;
    private AudioSource audioSource;
    private Camera mainCamera;
    private bool isAnimatingPage = false;
    
    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
            SetupAudio();
            journalDatabase.Initialize();
            mainCamera = Camera.main;
            InstantiateJournalPrefab();
        }
        else
        {
            Destroy(gameObject);
        }
    }
    
    void SetupAudio()
    {
        audioSource = gameObject.AddComponent<AudioSource>();
        audioSource.playOnAwake = false;
    }
    
    void InstantiateJournalPrefab()
    {
        if (journalPrefab != null && journalInstance == null)
        {
            journalInstance = Instantiate(journalPrefab);
            journalInstance.transform.SetParent(transform, false);
            DontDestroyOnLoad(journalInstance);
            bookPages = journalInstance.transform.Find("BookPages")?.GetComponent<Image>();
            if (bookPages == null)
            {
                Debug.LogError("JournalManager: BookPages child with Image component not found in prefab!");
            }
            
            journalInstance.SetActive(false);
        }
        else if (journalPrefab == null)
        {
            Debug.LogError("JournalManager: Journal prefab reference is missing!");
        }
    }
    
    void OnEnable()
    {
        SceneManager.sceneLoaded += OnSceneLoaded;
    }
    
    void OnDisable()
    {
        SceneManager.sceneLoaded -= OnSceneLoaded;
    }
    
    void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        mainCamera = Camera.main;
        if (journalInstance != null)
        {
            journalInstance.SetActive(false);
        }
    }
    
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.I))
        {
            ToggleJournal();
        }

        if (journalInstance && journalInstance.activeSelf && !isAnimatingPage)
        {
            if (Input.GetKeyDown(KeyCode.RightArrow) || Input.GetKeyDown(KeyCode.D))
            {
                NextPage();
            }
            if (Input.GetKeyDown(KeyCode.LeftArrow) || Input.GetKeyDown(KeyCode.A))
            {
                PreviousPage();
            }
        }
    }
    
    public void ToggleJournal()
    {
        try 
        {
            if (journalInstance != null)
            {
                bool newState = !journalInstance.activeSelf;
                Debug.Log($"Toggling journal to {newState}");
                journalInstance.SetActive(newState);

                if (newState)
                {
                   ShowCurrentPage();
                }
            }
        else
        {
            Debug.LogError("Journal instance is null!");
        }
    }
        catch (System.Exception e)
        {
        Debug.LogError($"Error in ToggleJournal: {e}");
        }
    }
    
    public void NextPage()
    {
        try 
        {
           Debug.Log($"Current page before attempt: {currentPage}");
            if (currentPage < journalDatabase.entries.Count - 1)
            {
                int nextUnlockedPage = -1;
                for (int i = currentPage + 1; i < journalDatabase.entries.Count; i++)
                {
                    if (journalDatabase.IsEntryUnlocked(i))
                    {
                        nextUnlockedPage = i;
                        break;
                    }
                }

               Debug.Log($"Next unlocked page found: {nextUnlockedPage}");

                if (nextUnlockedPage != -1)
                {
                   PlayPageFlipSound();
                    StartCoroutine(AnimatePageTurn(true));
                    currentPage = nextUnlockedPage;
                    Debug.Log($"Successfully moved to page {currentPage}");
                }
                else
                {
                    Debug.Log("No unlocked pages found ahead");
                }
            }
            else
            {
            Debug.Log("Already at last page");
            }
        }
        catch (System.Exception e)
        {
        Debug.LogError($"Error in NextPage: {e}");
        }
    }

    public void PreviousPage()
    {
        try
        {
            Debug.Log($"Current page before attempt: {currentPage}");
            if (currentPage > 0)
            {
                int prevUnlockedPage = -1;
                for (int i = currentPage - 1; i >= 0; i--)
                {
                    if (journalDatabase.IsEntryUnlocked(i))
                    {
                        prevUnlockedPage = i;
                        break;
                    }
                }

                Debug.Log($"Previous unlocked page found: {prevUnlockedPage}");
            
                if (prevUnlockedPage != -1)
                {
                    PlayPageFlipSound();
                    StartCoroutine(AnimatePageTurn(false));
                    currentPage = prevUnlockedPage;
                    Debug.Log($"Successfully moved to page {prevUnlockedPage}");
                }
                else
                {
                    Debug.Log("No unlocked pages found before");
                }
            }
            else
            {
                Debug.Log("Already at first page");
            }
        }
        catch (System.Exception e)
        {
            Debug.LogError($"Error in PreviousPage: {e}");
        }
    }
    
    IEnumerator AnimatePageTurn(bool isForward)
    {
        isAnimatingPage = true;
        
        float duration = 0.3f;
        float elapsed = 0f;
        
        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            float progress = elapsed / duration;
            Color currentColor = bookPages.color;
            currentColor.a = isForward ? (1 - progress) : progress;
            bookPages.color = currentColor;
            
            yield return null;
        }
        ShowCurrentPage();
        Color finalColor = bookPages.color;
        finalColor.a = 1f;
        bookPages.color = finalColor;
        
        isAnimatingPage = false;
    }
    
    private void ShowCurrentPage()
    {
    try 
    {
        Debug.Log($"Attempting to show page {currentPage}");
        
        if (bookPages == null)
        {
            Debug.LogError("bookPages reference is null!");
            return;
        }

        if (journalDatabase == null)
        {
            Debug.LogError("journalDatabase reference is null!");
            return;
        }

        if (currentPage < 0 || currentPage >= journalDatabase.entries.Count)
        {
            Debug.LogError($"Invalid page index: {currentPage}. Valid range: 0-{journalDatabase.entries.Count - 1}");
            return;
        }

        JournalEntryData entry = journalDatabase.entries[currentPage];
        if (entry == null)
        {
            Debug.LogError($"No entry found at index {currentPage}");
            return;
        }

        Debug.Log($"Entry found: {entry.plantName}");
        Debug.Log($"Is unlocked: {journalDatabase.IsEntryUnlocked(currentPage)}");
        Debug.Log($"Has pageSpread: {entry.pageSpread != null}");

        if (journalDatabase.IsEntryUnlocked(currentPage))
        {
            if (entry.pageSpread == null)
            {
                Debug.LogError($"No page spread sprite assigned for {entry.plantName}");
                return;
            }
            bookPages.sprite = entry.pageSpread;
            bookPages.enabled = true;
            Debug.Log($"Successfully displayed page for {entry.plantName}");
        }
        else
        {
            bookPages.enabled = false;
            Debug.Log($"Page {currentPage} is locked, hiding image");
        }
    }
    catch (System.Exception e)
    {
        Debug.LogError($"Error in ShowCurrentPage: {e}");
    }
    }
    
    void PlayPageFlipSound()
    {
        if (audioSource && pageFlipSound)
        {
            audioSource.PlayOneShot(pageFlipSound);
        }
    }
    
    public void UnlockEntry(string plantName)
    {
        journalDatabase.UnlockEntry(plantName);
        StartCoroutine(PlayUnlockEffect());
    }
    
    IEnumerator PlayUnlockEffect()
    {
        if (audioSource && unlockSound)
        {
            audioSource.PlayOneShot(unlockSound);
        }
    
        if (sparkleEffectPrefab != null && mainCamera != null)
        {
            float screenAspect = (float)Screen.width / Screen.height;
            float cameraHeight = mainCamera.orthographicSize * 2;
            float cameraWidth = cameraHeight * screenAspect;
            
            for (int i = 0; i < 10; i++)
            {
                Vector3 randomPosition = new Vector3(
                    Random.Range(mainCamera.transform.position.x - cameraWidth/2, mainCamera.transform.position.x + cameraWidth/2),
                    Random.Range(mainCamera.transform.position.y - cameraHeight/2, mainCamera.transform.position.y + cameraHeight/2),
                    0
                );
                
                GameObject sparkle = Instantiate(sparkleEffectPrefab, randomPosition, Quaternion.identity);
                sparkle.transform.rotation = Quaternion.Euler(0, 0, Random.Range(0f, 360f));
                float randomScale = Random.Range(0.8f, 1.2f);
                sparkle.transform.localScale = new Vector3(randomScale, randomScale, 1f);
                Destroy(sparkle, 2f);
                yield return new WaitForSeconds(0.1f);
            }
        }
    }
}