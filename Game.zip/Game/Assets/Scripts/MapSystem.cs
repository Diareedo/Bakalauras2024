using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using UnityEngine.EventSystems;

public class MapSystem : MonoBehaviour 
{
    private static MapSystem _instance;
    public static MapSystem Instance
    {
        get
        {
            if (_instance == null)
            {
                var existing = GameObject.Find("PersistentMapSystem");
                if (existing != null)
                {
                    _instance = existing.GetComponent<MapSystem>();
                }
            }
            return _instance;
        }
    }

    [Header("Scene Configuration")]
    [SerializeField] private string[] sceneNames;
    [SerializeField] private Vector2[] spawnPositions;
    [SerializeField] private GameObject mapCanvasPrefab;

    private GameObject mapCanvas;
    private EventSystem eventSystem;

    private void Awake()
    {
        if (_instance == null)
        {
            Debug.Log("Setting up new MapSystem instance");
            _instance = this;
            gameObject.name = "PersistentMapSystem";
            DontDestroyOnLoad(gameObject);
            SetupMapCanvas();
            EnsureEventSystem();
        }
        else if (_instance != this)
        {
            Debug.Log("Destroying duplicate MapSystem");
            Destroy(gameObject);
        }
    }

    private void EnsureEventSystem()
    {
        if (FindObjectOfType<EventSystem>() == null)
        {
            GameObject eventSystemObj = new GameObject("PersistentEventSystem");
            eventSystem = eventSystemObj.AddComponent<EventSystem>();
            eventSystemObj.AddComponent<StandaloneInputModule>();
            DontDestroyOnLoad(eventSystemObj);
        }
    }

    private void SetupMapCanvas()
    {
        if (mapCanvas != null) return;

        Debug.Log("Creating map canvas");
        mapCanvas = Instantiate(mapCanvasPrefab);
        mapCanvas.name = "PersistentMapCanvas";
        DontDestroyOnLoad(mapCanvas);

        Canvas canvas = mapCanvas.GetComponent<Canvas>();
        if (canvas != null)
        {
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 999;
        }

        Button[] buttons = mapCanvas.GetComponentsInChildren<Button>();
        Debug.Log($"Setting up {buttons.Length} buttons");
        
        for (int i = 0; i < buttons.Length && i < sceneNames.Length; i++)
        {
            int index = i;
            Button btn = buttons[i];
            btn.onClick.RemoveAllListeners();
            btn.onClick.AddListener(() => TravelToScene(index));
            Debug.Log($"Set up button {i} for scene: {sceneNames[i]}");
        }

        mapCanvas.SetActive(false);
    }

    private void OnEnable()
    {
        SceneManager.sceneLoaded += OnSceneLoaded;
    }

    private void OnDisable()
    {
        SceneManager.sceneLoaded -= OnSceneLoaded;
    }

    private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        EnsureEventSystem();
        EventSystem[] systems = FindObjectsOfType<EventSystem>();
        for (int i = 1; i < systems.Length; i++)
        {
            Destroy(systems[i].gameObject);
        }

        if (mapCanvas != null)
        {
            mapCanvas.SetActive(false);
        }
        Time.timeScale = 1f;
    }

    private void TravelToScene(int index)
    {
        if (index < 0 || index >= sceneNames.Length) 
        {
            Debug.LogError($"Invalid scene index: {index}");
            return;
        }

        string targetScene = sceneNames[index];
        string currentScene = SceneManager.GetActiveScene().name;
        
        Debug.Log($"Attempting to travel from {currentScene} to {targetScene}");

        if (currentScene == targetScene)
        {
            Debug.Log("Already in target scene");
            mapCanvas.SetActive(false);
            Time.timeScale = 1f;
            return;
        }

    GameManager.Instance.SavePlayerData();
    PlayerPrefs.SetFloat("SpawnPositionX", spawnPositions[index].x);
    PlayerPrefs.SetFloat("SpawnPositionY", spawnPositions[index].y);
    PlayerPrefs.Save();
    
    string debugData = PlayerPrefs.GetString("InventoryData");
    Debug.Log($"PRE-TRANSITION INVENTORY DATA: {debugData}");
    
    mapCanvas.SetActive(false);
    Time.timeScale = 1f;
    SceneManager.LoadScene(targetScene);
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.M))
        {
            if (mapCanvas != null)
            {
                bool newState = !mapCanvas.activeSelf;
                mapCanvas.SetActive(newState);
                Time.timeScale = newState ? 0f : 1f;
            }
        }
    }
}