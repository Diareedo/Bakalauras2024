using UnityEngine;
using System.Collections.Generic;

[CreateAssetMenu(fileName = "Journal Database", menuName = "Journal/Database")]
public class JournalDatabase : ScriptableObject
{
    public List<JournalEntryData> entries;
    [System.NonSerialized]
    private List<bool> unlockedStates;
    
    public void Initialize()
    {
        if (unlockedStates == null)
        {
            unlockedStates = new List<bool>();
            for (int i = 0; i < entries.Count; i++)
            {
               bool isUnlocked = i == 0 || PlayerPrefs.GetInt($"JournalEntry_{entries[i].plantName}", 0) == 1;
               Debug.Log($"Entry {entries[i].plantName} unlock state: {isUnlocked}");
               unlockedStates.Add(isUnlocked);
            }
        }
    }
    
    public bool IsEntryUnlocked(int index)
    {
        Initialize();
        return unlockedStates != null && index < unlockedStates.Count && unlockedStates[index];
    }
    
    public void UnlockEntry(string plantName)
    {
        Initialize();
        Debug.Log($"Trying to unlock entry for plant: {plantName}");
        int index = entries.FindIndex(entry => entry.plantName == plantName);
        Debug.Log($"Found index in entries: {index}");
        if (index != -1 && !unlockedStates[index])
        {
            unlockedStates[index] = true;
            PlayerPrefs.SetInt($"JournalEntry_{plantName}", 1);
            PlayerPrefs.Save();
        }
    }
}