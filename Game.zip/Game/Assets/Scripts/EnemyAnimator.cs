using UnityEngine;

[RequireComponent(typeof(Animator))]
[RequireComponent(typeof(SpriteRenderer))]
public class EnemyAnimator : MonoBehaviour
{
    [Header("Animation Sprites")]
    [SerializeField] private Sprite idleSprite;             
    [SerializeField] private Sprite[] walkingSprites;       
    [SerializeField] private Sprite[] runningSprites;       
    
    [Header("Animation Settings")]
    [SerializeField] private float walkFrameRate = 12f;     
    [SerializeField] private float runFrameRate = 15f;      
    private Animator animator;
    private SpriteRenderer spriteRenderer;
    private float walkFrameTimer;
    private float runFrameTimer;
    private int currentWalkFrame;
    private int currentRunFrame;

    void Start()
    {
        animator = GetComponent<Animator>();
        spriteRenderer = GetComponent<SpriteRenderer>();
        
        // Start with idle sprite
        spriteRenderer.sprite = idleSprite;
    }

    public void SetIdle()
    {
        spriteRenderer.sprite = idleSprite;
    }

    public void UpdateWalkingAnimation()
    {
        walkFrameTimer += Time.deltaTime;
        if (walkFrameTimer >= 1f / walkFrameRate)
        {
            walkFrameTimer = 0f;
            currentWalkFrame = (currentWalkFrame + 1) % walkingSprites.Length;
            spriteRenderer.sprite = walkingSprites[currentWalkFrame];
        }
    }

    public void UpdateRunningAnimation()
    {
        runFrameTimer += Time.deltaTime;
        if (runFrameTimer >= 1f / runFrameRate)
        {
            runFrameTimer = 0f;
            currentRunFrame = (currentRunFrame + 1) % runningSprites.Length;
            spriteRenderer.sprite = runningSprites[currentRunFrame];
        }
    }
}