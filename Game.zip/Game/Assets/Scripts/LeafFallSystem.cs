using UnityEngine;
using System.Collections.Generic;

[System.Serializable]
public class LeafType {
    public Sprite[] sprites;
    [Range(0.1f, 2f)]
    public float animationSpeed = 0.2f;
}

public class LeafFallSystem : MonoBehaviour {
    [Header("Leaf Configuration")]
    public LeafType[] leafTypes;
    public float spawnRadius = 15f;
    public float leafLifetime = 20f;
    public int leavesPerSecond = 20;
    
    [Header("Movement Configuration")]
    public float minWindForce = 0.5f;
    public float maxWindForce = 2f;
    public float windChangeInterval = 2f;
    public float swayAmount = 0.5f;
    public float windTransitionSpeed = 2f;
    public float downwardBias = 0.8f;
    
    private Transform playerTransform;
    private Camera mainCamera;
    private List<Leaf> activeLeaves;
    private float nextWindChange;
    private Vector2 currentWind;
    private Vector2 targetWind;
    private float nextSpawnTime;
    private float spawnInterval;
    
    private void Start() {
        playerTransform = GameObject.FindGameObjectWithTag("Player").transform;
        mainCamera = Camera.main;
        activeLeaves = new List<Leaf>();
        UpdateWindTarget();
        spawnInterval = 1f / leavesPerSecond;
        nextSpawnTime = Time.time;
    }
    
    private void Update() {
        if (Time.time >= nextWindChange) {
            UpdateWindTarget();
            nextWindChange = Time.time + windChangeInterval;
        }
        
        currentWind = Vector2.Lerp(currentWind, targetWind, Time.deltaTime * windTransitionSpeed);
        
        while (Time.time >= nextSpawnTime) {
            SpawnLeaf();
            nextSpawnTime += spawnInterval;
        }
        
        for (int i = activeLeaves.Count - 1; i >= 0; i--) {
            if (!activeLeaves[i].UpdateLeaf(currentWind)) {
                Destroy(activeLeaves[i].gameObject);
                activeLeaves.RemoveAt(i);
            }
        }
    }
    
    private Vector3 GetSpawnPosition() {
        float cameraHeight = 2f * mainCamera.orthographicSize;
        float cameraWidth = cameraHeight * mainCamera.aspect;
        
        float padding = 1f;
        
        float spawnTop = mainCamera.transform.position.y + (cameraHeight / 2f) + padding;
        float spawnLeft = mainCamera.transform.position.x - (cameraWidth / 2f) - padding;
        float spawnRight = mainCamera.transform.position.x + (cameraWidth / 2f) + padding;
        
        float randomX;
        float randomY;
        
        if (Random.value < 0.7f) {
            randomX = Random.Range(spawnLeft, spawnRight);
            randomY = spawnTop;
        } else {
            if (Random.value < 0.5f) {
                randomX = spawnLeft;
            } else {
                randomX = spawnRight;
            }
            randomY = Random.Range(
                mainCamera.transform.position.y - (cameraHeight / 2f),
                spawnTop
            );
        }
        
        return new Vector3(randomX, randomY, 0);
    }
    
    private void SpawnLeaf() {
        Vector3 spawnPos = GetSpawnPosition();
        
        GameObject leafObj = new GameObject("Leaf");
        leafObj.transform.position = spawnPos;
        
        SpriteRenderer spriteRenderer = leafObj.AddComponent<SpriteRenderer>();
        spriteRenderer.transform.localScale = new Vector3(0.5f, 0.5f, 1f);
        spriteRenderer.sortingOrder = Random.Range(1, 10);
        
        Leaf leaf = leafObj.AddComponent<Leaf>();
        LeafType selectedType = leafTypes[Random.Range(0, leafTypes.Length)];
        leaf.Initialize(selectedType, leafLifetime, swayAmount);
        
        activeLeaves.Add(leaf);
    }
    
    private void UpdateWindTarget() {
        float angle = Random.Range(-45f, 45f) * Mathf.Deg2Rad;
        float force = Random.Range(minWindForce, maxWindForce);
        Vector2 windDir = new Vector2(Mathf.Cos(angle), Mathf.Sin(angle));
        targetWind = windDir * force;
        targetWind.y -= downwardBias;
    }
}

public class Leaf : MonoBehaviour {
    private SpriteRenderer spriteRenderer;
    private LeafType leafType;
    private float lifetime;
    private float swayAmount;
    
    private float spawnTime;
    private int currentFrame;
    private float animationTimer;
    private Vector2 baseVelocity;
    private Vector2 currentVelocity;
    
    public void Initialize(LeafType type, float lifetime, float swayAmount) {
        this.spriteRenderer = GetComponent<SpriteRenderer>();
        this.leafType = type;
        this.lifetime = lifetime;
        this.swayAmount = swayAmount;
        
        spriteRenderer.sprite = type.sprites[0];
        spawnTime = Time.time;
        baseVelocity = new Vector2(Random.Range(-0.5f, 0.5f), -Random.Range(0.2f, 0.8f));
        currentVelocity = baseVelocity;
        animationTimer = 0f;
    }
    
    public bool UpdateLeaf(Vector2 windForce) {
        if (Time.time - spawnTime >= lifetime) {
            return false;
        }
        
        animationTimer += Time.deltaTime;
        if (animationTimer >= leafType.animationSpeed) {
            animationTimer = 0f;
            currentFrame = (currentFrame + 1) % leafType.sprites.Length;
            spriteRenderer.sprite = leafType.sprites[currentFrame];
        }
        
        currentVelocity = Vector2.Lerp(currentVelocity, baseVelocity + windForce, Time.deltaTime * 2f);
        Vector2 movement = currentVelocity * Time.deltaTime;
        
        float swayX = Mathf.Sin(Time.time * 1.5f + transform.position.x) * swayAmount;
        float swayY = Mathf.Cos(Time.time * 1.2f + transform.position.y) * (swayAmount * 0.5f);
        
        transform.position += new Vector3(
            movement.x + (swayX * Time.deltaTime),
            movement.y + (swayY * Time.deltaTime),
            0
        );
        
        return true;
    }
}